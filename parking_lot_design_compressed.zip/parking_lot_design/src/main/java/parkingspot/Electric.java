package parkingspot;

/**
Created by Arshabh Semwal on Jun 30, 2020
*/

import abstracts.ParkingSpot;
import enums.ParkingSpotType;

public class Electric extends ParkingSpot{
	
	public Electric() {
		super(ParkingSpotType.ELECTRIC_SMALL);
	}
	@Override
	public boolean IsFree() {
		// TODO Auto-generated method stub
		if(this.isFree()==true) {
			return true;
		}
		return false;
	}

}


