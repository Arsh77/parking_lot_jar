package parkingspot;

/**
Created by Arshabh Semwal on Jun 30, 2020
*/

import abstracts.ParkingSpot;
import enums.ParkingSpotType;

public class HandicappedSpot extends ParkingSpot{
	
	public HandicappedSpot() {
		super(ParkingSpotType.HANDICAP);
	}
	
	@Override
	public boolean IsFree() {
		// TODO Auto-generated method stub
		if(this.isFree()==true) {
			return true;
		}
		return false;
	}
	
}


