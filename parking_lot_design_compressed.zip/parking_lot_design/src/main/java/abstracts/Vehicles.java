package abstracts;

import bean.ParkingTicket;
import enums.VehicleType;

/**
 * Created by Arshabh Semwal on Jun 27, 2020
 */

public abstract class Vehicles {
	private String licenseNumber;
	private final VehicleType vehicletype;
	private ParkingTicket ticket;

	public Vehicles(VehicleType vehicletype) {
	    this.vehicletype = vehicletype;
	  }

	public void assignTicket(ParkingTicket ticket) {
		this.ticket = ticket;
	}
}
