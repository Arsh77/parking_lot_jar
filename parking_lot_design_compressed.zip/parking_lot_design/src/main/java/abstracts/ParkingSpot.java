package abstracts;

import enums.ParkingSpotType;

/**
 * Created by Arshabh Semwal on Jun 27, 2020
 */

public abstract class ParkingSpot {
	private String number;
	private boolean free;
	private Vehicles vehicle;
	private final ParkingSpotType type;

	public abstract boolean IsFree();

	public ParkingSpot(ParkingSpotType type) {
		this.type = type;
	}

	public boolean assignVehicle(Vehicles vehicle) {
		this.vehicle = vehicle;
		free = false;
		return true;
	}

	public boolean removeVehicle() {
		this.vehicle = null;
		free = true;
		return true;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public boolean isFree() {
		return free;
	}

	public void setFree(boolean free) {
		this.free = free;
	}

	public Vehicles getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicles vehicle) {
		this.vehicle = vehicle;
	}

	public ParkingSpotType getType() {
		return type;
	}
	
	
}
