package entities;

import abstracts.Account;

/**
Created by Arshabh Semwal on Jun 27, 2020
*/

public class ParkingAttendant extends Account{
	/*
	public bool processTicket(string TicketNumber);*/

	@Override
	public boolean resetPassword() {
		// TODO Auto-generated method stub
		return false;
	}
	
}


