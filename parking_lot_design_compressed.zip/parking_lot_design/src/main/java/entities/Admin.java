package entities;

import abstracts.Account;

/**
 * Created by Arshabh Semwal on Jun 27, 2020
 */

public class Admin extends Account{
	/*
	public bool addParkingFloor(ParkingFloor floor);
	
	public bool addParkingSpot(String floorName, ParkingSpot spot);
	
	public bool addParkingDisplayBoard(String floorName, ParkingDisplayBoard displayBoard);
	
	public bool addCustomerInfoPanel(String floorName, CustomerInfoPortal infoPanel);
	
	public bool addEntrancePanel(EntrancePanel entrancePanel);
	
	public bool addExitPanel(ExitPanel exitPanel);*/

	@Override
	public boolean resetPassword() {
		// TODO Auto-generated method stub
		return false;
	}
	
}
