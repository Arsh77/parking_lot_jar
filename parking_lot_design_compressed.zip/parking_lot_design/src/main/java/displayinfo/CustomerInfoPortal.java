package displayinfo;

/**
Created by Arshabh Semwal on Jun 30, 2020
*/

public class CustomerInfoPortal {
	
	//get car spot by registration number
	
	//pay for ticket 
	
	//
}


