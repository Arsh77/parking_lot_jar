package vehicletype;

import abstracts.Vehicles;
import enums.VehicleType;

/**
Created by Arshabh Semwal on Jun 27, 2020
*/

public class Car extends Vehicles{
	public Car() {
	    super(VehicleType.CAR);
	  }
}


