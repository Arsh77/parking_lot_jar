package vehicletype;

import abstracts.Vehicles;
import enums.VehicleType;

/**
Created by Arshabh Semwal on Jun 27, 2020
*/

public class ElectricTruck extends Vehicles{
	public ElectricTruck() {
		super(VehicleType.ELECTRIC_TRUCK);
	}
}


