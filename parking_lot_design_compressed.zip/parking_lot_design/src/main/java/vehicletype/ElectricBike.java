package vehicletype;

import abstracts.Vehicles;
import enums.VehicleType;

/**
Created by Arshabh Semwal on Jun 27, 2020
*/

public class ElectricBike extends Vehicles{
	public ElectricBike() {
		super(VehicleType.ELECTRIC_BIKE);
	}
}


