package vehicletype;

import abstracts.Vehicles;
import enums.VehicleType;

/**
Created by Arshabh Semwal on Jun 27, 2020
*/

public class MotorBike extends Vehicles{
	public MotorBike() {
		super(VehicleType.MOTORBIKE);
	}
}


