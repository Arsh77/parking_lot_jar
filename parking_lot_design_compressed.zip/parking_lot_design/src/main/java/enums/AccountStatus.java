package enums;

public enum AccountStatus {
	ACTIVE, CLOSED, BLOCKED, BANNED, COMPROMISED, ARCHIVED, UNKNOWN, NONE;
}
