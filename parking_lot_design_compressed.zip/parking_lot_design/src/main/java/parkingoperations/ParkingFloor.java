package parkingoperations;

import java.util.HashMap;

import abstracts.ParkingSpot;
import abstracts.Vehicles;
import displayinfo.*;
import parkingspot.*;
import enums.ParkingSpotType;
/**
Created by Arshabh Semwal on Jun 30, 2020
 * @param <Vehicle>
*/

public class ParkingFloor<Vehicle> {
	private String name;
	  private HashMap<String, HandicappedSpot> handicappedSpots;
	  private HashMap<String, Compact> compactSpots;
	  private HashMap<String, Large> largeSpots;
	  private HashMap<String, Motorbike> motorbikeSpots;
	  private HashMap<String, Electric> electricSpots;
	  private HashMap<String, CustomerInfoPortal> infoPortals;
	  private ParkingDisplayBoard displayBoard;

	  public ParkingFloor(String name) {
	    this.name = name;
	  }

	  public void addParkingSpot(ParkingSpot spot) {
	    switch (spot.getType()) {
	    case HANDICAP:
	      handicappedSpots.put("1", (HandicappedSpot) spot);
	      break;
	    case SMALL:
	      compactSpots.put(spot.getNumber(), (Compact) spot);
	      break;
	    case LARGE:
	      largeSpots.put(spot.getNumber(), (Large) spot);
	      break;
	    case MOTORBIKE:
	      motorbikeSpots.put(spot.getNumber(), (Motorbike) spot);
	      break;
	    case ELECTRIC_SMALL:
	      electricSpots.put(spot.getNumber(), (Electric) spot);
	      break;
	    default:
	      System.out.println("Wrong parking spot type!");
	    }
	  }

	  public void assignVehicleToSpot(Vehicles vehicle, ParkingSpot spot) {
	    spot.assignVehicle(vehicle);
	    switch (spot.getType()) {
	    case HANDICAP:
	      updateDisplayBoardForHandicapped(spot);
	      break;
	    case SMALL:
	      updateDisplayBoardForCompact(spot);
	      break;
	    case LARGE:
	      updateDisplayBoardForLarge(spot);
	      break;
	    case MOTORBIKE:
	      updateDisplayBoardForMotorbike(spot);
	      break;
	    case ELECTRIC_SMALL:
	      updateDisplayBoardForElectric(spot);
	      break;
	    default:
	      System.out.println("Wrong parking spot type!");
	    }
	  }

	  private void updateDisplayBoardForElectric(ParkingSpot spot) {
		// TODO Auto-generated method stub
		
	}

	private void updateDisplayBoardForMotorbike(ParkingSpot spot) {
		// TODO Auto-generated method stub
		
	}

	private void updateDisplayBoardForLarge(ParkingSpot spot) {
		// TODO Auto-generated method stub
		
	}

	private void updateDisplayBoardForHandicapped(ParkingSpot spot) {
	    if (this.displayBoard.getHandicappedFreeSpot().getNumber() == spot.getNumber()) {
	      // find another free handicapped parking and assign to displayBoard
	      for (String key : handicappedSpots.keySet()) {
	        if (handicappedSpots.get(key).isFree()) {
	          this.displayBoard.setHandicappedFreeSpot(handicappedSpots.get(key));
	        }
	      }
	      this.displayBoard.showEmptySpotNumber();
	    }
	  }

	  private void updateDisplayBoardForCompact(ParkingSpot spot) {
	    if (this.displayBoard.getCompactFreeSpot().getNumber() == spot.getNumber()) {
	      // find another free compact parking and assign to displayBoard
	      for (String key : compactSpots.keySet()) {
	        if (compactSpots.get(key).isFree()) {
	          this.displayBoard.setCompactFreeSpot(compactSpots.get(key));
	        }
	      }
	      this.displayBoard.showEmptySpotNumber();
	    }
	  }

	  public void freeSpot(ParkingSpot spot) {
	    spot.removeVehicle();
	    switch (spot.getType()) {
	    case HANDICAP:
	      freeHandicappedSpotCount++;
	      break;
	    case ParkingSpotType.SMALL:
	      freeCompactSpotCount++;
	      break;
	    case ParkingSpotType.LARGE:
	      freeLargeSpotCount++;
	      break;
	    case ParkingSpotType.MOTORBIKE:
	      freeMotorbikeSpotCount++;
	      break;
	    case ParkingSpotType.ELECTRIC_SMALL:
	      freeElectricSpotCount++;
	      break;
	    default:
	      print("Wrong parking spot type!");
	    }
	  }
}


