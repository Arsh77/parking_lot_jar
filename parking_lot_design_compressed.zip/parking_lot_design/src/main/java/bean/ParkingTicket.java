package bean;

import java.util.Date;

/**
Created by Arshabh Semwal on Jun 30, 2020
*/

public class ParkingTicket {
	
	private String parkingName="Default";
	private int floor;
	private String ticketNumber;
	private String slotNo;
	private Date datetime;
	private String entranceGate;
	
	public ParkingTicket(String slotNo) {
		this.slotNo=slotNo;
		this.datetime=new Date();
	}
	
	public ParkingTicket(String slotNo, int floor, String entranceGate) {
		this.slotNo=slotNo;
		this.datetime=new Date();
		this.floor=floor;
		this.entranceGate=entranceGate;
	}

	public String getParkingName() {
		return parkingName;
	}

	public void setParkingName(String parkingName) {
		this.parkingName = parkingName;
	}

	public int getFloor() {
		return floor;
	}

	public void setFloor(int floor) {
		this.floor = floor;
	}

	public String getSlotNo() {
		return slotNo;
	}

	public void setSlotNo(String slotNo) {
		this.slotNo = slotNo;
	}

	public Date getDatetime() {
		return datetime;
	}

	public void setDatetime(Date datetime) {
		this.datetime = datetime;
	}

	public String getEntranceGate() {
		return entranceGate;
	}

	public void setEntranceGate(String entranceGate) {
		this.entranceGate = entranceGate;
	}

	public String getTicketNumber() {
		return ticketNumber;
	}

	public void setTicketNumber(String ticketNumber) {
		this.ticketNumber = ticketNumber;
	}
	
}


